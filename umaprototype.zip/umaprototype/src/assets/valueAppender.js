function elementAppender(z) {
var element = document.getElementById(z);
var textboxes = document.getElementsByTagName('input');
for(var i = 0; i < element.children.length; i++) {
var currentText = element.children[z].children[i].innerHTML;
textboxes[i].value = currentText;
}
}
var elements = document.getElementsByName('todelete');
for(var i = 0; i < elements.length; i++) {
elements[i].children[3].children[0].onclick= elementAppender(i);
}
