import { NgModule } from '@angular/core';
import { UserTemplateComponent } from './user/user-template/user-template.component';
import { UserConstructorComponent } from './user/user-constructor/user-constructor.component';
import { UserModifierComponent } from './user/user-modifier/user-modifier.component';
import { UserEraserComponent } from './user/user-eraser/user-eraser.component';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', component: UserTemplateComponent},
  { path: 'add', component: UserConstructorComponent},
  { path: 'erase', component: UserEraserComponent},
  { path: 'modify', component: UserModifierComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }