import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { UserTemplateComponent } from './user/user-template/user-template.component';
import { UserConstructorComponent } from './user/user-constructor/user-constructor.component';
import { Routes, RouterModule } from "@angular/router";
import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { UserService } from './user/user.service';
import { UserModifierComponent } from './user/user-modifier/user-modifier.component';
import { UserEraserComponent } from './user/user-eraser/user-eraser.component';
const routes: Routes = [
  {
    path: '',
    component: UserTemplateComponent
  },

  {
    path: 'add',
    component: UserConstructorComponent
  }
];
@NgModule({
  declarations: [
    AppComponent,
    UserTemplateComponent,
    UserConstructorComponent,
    UserModifierComponent,
    UserEraserComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
    IonicModule
  ],
  providers: [
UserService
],
  bootstrap: [AppComponent]
})
export class AppModule { }
