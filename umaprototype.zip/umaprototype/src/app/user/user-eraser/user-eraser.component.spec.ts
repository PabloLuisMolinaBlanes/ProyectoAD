import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserEraserComponent } from './user-eraser.component';

describe('UserEraserComponent', () => {
  let component: UserEraserComponent;
  let fixture: ComponentFixture<UserEraserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserEraserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserEraserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
