import { Component, OnInit } from '@angular/core';
import { User } from '../user-template/user';
import { UserService } from '../user.service';
import { Observable, of } from 'rxjs';
import { AlertController } from '@ionic/angular';
@Component({
  selector: 'app-user-eraser',
  templateUrl: './user-eraser.component.html',
  styleUrls: ['./user-eraser.component.css']
})
export class UserEraserComponent implements OnInit {
  public personArray: Array<User> = [];
  public myObservable: Observable<any> = this.userService.getAll();
  public person: any;
  public definitePerson: User;
  public number = 0;
  public userArrPriv: User[] = [];
  constructor(private userService: UserService, private alertCtrl: AlertController) { }
  ngOnInit(): void {
    const myObserver = {
      next: x => {
        for (var i = 0; i < x.data.length; i++) {
          this.person = x;
          console.log(this.person.data[this.number].id);
          this.definitePerson = new User(this.person.data[this.number].id, this.person.data[this.number].name, this.person.data[this.number].status, this.person.data[this.number].building, this.person.data[this.number].picture);
          console.log(this.person);
          console.log(this.definitePerson.id);
          this.personArray.push(this.definitePerson);
          this.number += 1;
        }
      },
      error: err => console.error('Observer got an error: ' + err),
      complete: () => console.log('Observer got a complete notification'),
    };
    this.myObservable.subscribe(myObserver);
    // this.personArray = [
    // new User(1, "Roberto", "PDI", "Departamento de Económicas", "roberto.jpg"),
    // new User(2, "Laura Lopez", "Personal de Limpieza", "Departamento de Matemáticas", "laura.jpg"),
    // new User(3, "Maria Perez", "PDI", "Departamento de Informñatica", "maria.jpg")
    //];
  }
  async erasePerson(id: number) {
    var self = this;
    let personArr = JSON.parse(localStorage.getItem('personarray'));
    let counter = 0;
    for (let person in personArr) {
      let id = personArr[counter].id;
      let name = personArr[counter].name;
      let status = personArr[counter].status;
      let building = personArr[counter].building;
      let picture = personArr[counter].picture;
      let currUser = new User(id, name, status, building, picture);
      this.userArrPriv.push(currUser);
      counter++;
    }
    console.log(id);
    this.presentAlert(id);
  }
  presentAlert(id: number) {
    if (confirm("¿Está seguro de querer borrar a " + this.personArray[id].name + "?")) {
      console.log("Deleting person " + this.personArray[id]);
      this.userArrPriv = this.userArrPriv.filter(a => a.id != id + 1);
    localStorage.setItem('personarray2', JSON.stringify(this.userArrPriv));
      this.userService.deleteUser(this.personArray[id]);
    } else {
    }
  }
}
