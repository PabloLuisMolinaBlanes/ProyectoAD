import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserConstructorComponent } from './user-constructor.component';

describe('UserConstructorComponent', () => {
  let component: UserConstructorComponent;
  let fixture: ComponentFixture<UserConstructorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserConstructorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserConstructorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
