import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { User } from '../user-template/user';
import { UserService } from '../user.service';
@Component({
  selector: 'app-user-constructor',
  templateUrl: './user-constructor.component.html',
  styleUrls: ['./user-constructor.component.css']
})
export class UserConstructorComponent implements OnInit {
  @Input() person: User;
  @Input() mode: string = "";
  @Input() human: User;
  @Input() userArraymio: User[] = [];
  userArrPriv: User[] = [];
  userservice: UserService;
  constructor(userservice: UserService) {
    this.person = new User(-1, "a", "a", "a", "a");
    this.human = new User(-1, "", "", "", "");
    this.userservice = userservice;
  }

  setNam(nombre) {
    this.person.name = nombre;
  }
  setLoc(loc) {
    this.person.building = loc;
  }
  setPos(pos) {
    this.person.status = pos;
  }
  setPic(pic) {
    this.person.picture = pic;
  }
  createPerson() {
    if (this.mode === 'modify') {
      let personArr = JSON.parse(localStorage.getItem('personarray'));
      let counter = 0;
      for (let person in personArr) {
        let id = personArr[counter].id;
        let name = personArr[counter].name;
        let status = personArr[counter].status;
        let building = personArr[counter].building;
        let picture = personArr[counter].picture;
        let currUser = new User(id, name, status, building, picture);
        this.userArrPriv.push(currUser);
        counter++;
      }
      this.userArrPriv[this.human.id-1] = this.human;
      localStorage.setItem('personarray', JSON.stringify(this.userArrPriv));
      console.log(personArr);
      console.log("Modifying person: ", this.human);
      this.userservice.modifyUser(this.human);
    } else {
      let personArr = JSON.parse(localStorage.getItem('personarray'));
      let counter = 0;
      for (let person in personArr) {
        let id = personArr[counter].id;
        let name = personArr[counter].name;
        let status = personArr[counter].status;
        let building = personArr[counter].building;
        let picture = personArr[counter].picture;
        let currUser = new User(id, name, status, building, picture);
        this.userArrPriv.push(currUser);
        counter++;
      }
      this.human.id = this.userArrPriv.length;
      this.userArrPriv.push(this.human);
      localStorage.setItem('personarray', JSON.stringify(this.userArrPriv));
      console.log("Creating person: ", this.human);
      this.userservice.createUser(this.human);
    }
  }
  ngOnInit(): void {
  }
}
