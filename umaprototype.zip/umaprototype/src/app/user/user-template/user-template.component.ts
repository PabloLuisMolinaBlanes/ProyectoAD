import { Component, OnInit } from '@angular/core';
import { User } from './user';
import {UserService} from '../user.service';
import { Observable, of } from 'rxjs';
@Component({
  selector: 'app-user-template',
  templateUrl: './user-template.component.html',
  styleUrls: ['./user-template.component.css']
})
export class UserTemplateComponent implements OnInit {
public personArray: Array<User> = [];
public myObservable: Observable<any> = this.userService.getAll();
public person: any;
public definitePerson: User;
public number =  0;
constructor(private userService: UserService) { }
  ngOnInit(): void {
const myObserver = {
next: x =>  {
for (var i = 0; i < x.data.length; i++) {
this.person = x;
console.log(this.person.data[this.number].id);
this.definitePerson = new User(this.person.data[this.number].id,this.person.data[this.number].name,this.person.data[this.number].status,this.person.data[this.number].building,this.person.data[this.number].picture);
console.log(this.person);
console.log(this.definitePerson.id);
this.personArray.push(this.definitePerson);
localStorage.setItem("personarray", JSON.stringify(this.personArray));
this.number += 1;
} 
},
error: err => console.error('Observer got an error: ' + err),
complete: () => console.log('Observer got a complete notification'),
};
this.myObservable.subscribe(myObserver);

 // this.personArray = [
 // new User(1, "Roberto", "PDI", "Departamento de Económicas", "roberto.jpg"),
 // new User(2, "Laura Lopez", "Personal de Limpieza", "Departamento de Matemáticas", "laura.jpg"),
 // new User(3, "Maria Perez", "PDI", "Departamento de Informñatica", "maria.jpg")
 //];
}
}
