export class User {
constructor(public id: number, public name: string, 
public status: string, public building: string, public picture: String) {
}
}
