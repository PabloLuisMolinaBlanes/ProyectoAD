import { Component, OnInit, Inject, AfterContentInit } from '@angular/core';
import { User } from '../user-template/user';
import { UserService } from '../user.service';
import { Observable, of } from 'rxjs';
import { UserConstructorComponent } from '../user-constructor/user-constructor.component';
import { DOCUMENT } from '@angular/common';
import { withLatestFrom } from 'rxjs/operators';
@Component({
  selector: 'app-user-modifier',
  templateUrl: './user-modifier.component.html',
  styleUrls: ['./user-modifier.component.css']
})

export class UserModifierComponent implements OnInit {

  public personArray: Array<User> = [];
  public people: Observable<any> = this.userService.getAll();
  public man: any;
  public currentPerson: User = new User(-1, 'a', 'a', 'a', 'a');
  public definitePerson: User;
  public number = 0;
  public summed = 0;
  public myself = this;
  constructor(private userService: UserService, @Inject(DOCUMENT) document) { }

  ngOnInit(): void {
    const myObserver = {
      next: personData => {
        for (var i = 0; i < personData.data.length; i++) {
          this.man = personData;
          this.definitePerson = new User(this.man.data[this.number].id, this.man.data[this.number].name, this.man.data[this.number].status, this.man.data[this.number].building, this.man.data[this.number].picture);
          this.personArray.push(this.definitePerson);
          this.number += 1;
        }
      },
      error: err => console.error('Observer got an error: ' + err),
      complete: () => console.log('Observer got a complete notification'),
    };

    this.people.subscribe(myObserver);
  }
  setPerson(id: number, name: string, status: string, building: string, picture: string) {
    this.currentPerson.id = id;
    this.currentPerson.name = name;
    this.currentPerson.status = status;
    this.currentPerson.building = building;
    this.currentPerson.picture = picture;
    console.log("Succesful change to " + id + status + building + picture);
  }
  modifyPerson() {
  }
}
