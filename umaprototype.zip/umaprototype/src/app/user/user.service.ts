import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { User } from './user-template/user';
import { tap } from 'rxjs/operators';
import { getAttrsForDirectiveMatching } from '@angular/compiler/src/render3/view/util';
@Injectable({
  providedIn: 'root'
})
export class UserService {
  baseUrl = 'http://localhost/';
  users: Array<any>;
  human: string;
  man: User;
  response: string;
  test: JSON;
  constructor(private http: HttpClient) { }

  getAll(): Observable<any> {
    console.log("Service opened correctly");
    let gato = this.http.get<any>('http://127.0.0.1/obtain.php');
    return gato;
  }
  deleteUser(person: User) {
    console.log("Hi, I am deleteUser");
    this.human = JSON.stringify(person);
    console.log(this.human);
    let gato = this.http.post<any>('http://127.0.0.1/personDelete.php', this.human).subscribe((data) => (this.response = data));
    while (this.response === "") {
    }
    console.log(this.response);
  }
  createUser(person: User) {
    console.log("Hi, I am createUser");
    this.human = JSON.stringify(person);
    console.log(this.human);
    let gato = this.http.post<any>('http://127.0.0.1/personUpload.php', this.human).subscribe((data) => (this.response = data));
    while (this.response === "") {
    }
    console.log(this.response);
  }
  modifyUser(person: User) {
    console.log("Hi, I am modifyUser");
    this.human =  JSON.stringify(person);
    console.log(this.human);
    this.http.post<any>('http://127.0.0.1/personModify.php', this.human).subscribe((data) => (this.response = data));
    while (this.response === "") {
    }
    console.log(this.response);
  }
}
