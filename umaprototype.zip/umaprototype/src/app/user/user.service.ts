import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { User } from './user-template/user';
import { tap } from 'rxjs/operators';
import { getAttrsForDirectiveMatching } from '@angular/compiler/src/render3/view/util';
@Injectable({
  providedIn: 'root'
})
export class UserService {
  baseUrl = 'http://localhost/';
  users: Array<any>;
  human: String;
  man: User;
  constructor(private http: HttpClient) { }

  getAll(): Observable<any> {
    console.log("Service opened correctly");
    let gato = this.http.get<any>('http://localhost/obtain.php');
    return gato;
  }
  deleteUser(person: User) {
    console.log("Hi, I am deleteUser");
    this.human = JSON.stringify(person);
    console.log(this.human);
/*
    this.http.post<any>('http://localhost/personDelete.php', this.human);
*/

  }
  createUser(person: User) {
    console.log("Hi, I am createUser");
    this.human = JSON.stringify(person);
    console.log(this.human);
    this.http.post<any>('http://localhost/personUpload.php', this.human);
  }
  modifyUser(person: User) {
    console.log("Hi, I am modifyUser");
    this.human =  JSON.stringify(person);
    console.log(this.human);
    this.http.post<any>('http://localhost/personModify.php', this.human);
  }
}
